import os


util_path = os.path.dirname(__file__)

print(util_path)