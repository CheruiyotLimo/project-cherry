# Cherry
This is a Python based CLI tool to create essentials for FastAPI backend development.

# Introduction 
 - Built with Python Click, you can easily create and activate virtual environments, insall some of the popular and necessary libraries and dependencies all with one command. 
 - Additionally, you can create files and directories in a specified hierachical order to ease project clutter also with one single command.
 - All python files are initiated with some boilerplate code and examples that you can customize according to your project needs.